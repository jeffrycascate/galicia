﻿#Region "Imports"

Imports System.Data
Imports System.Globalization
Imports DevExpress.Web.ASPxEditors
Imports GIT.Core
Imports InMotionGIT.Common.Helpers
Imports InMotionGIT.Common.Proxy
Imports InMotionGIT.Core.Configuration
Imports InMotionGIT.FrontOffice.Contracts
Imports InMotionGIT.FrontOffice.Proxy
Imports InMotionGIT.FrontOffice.Support
Imports InMotionGIT.FrontOffice.Support.User

#End Region

Partial Class dropthings_Admin_Initialization
    Inherits PageBase

#Region "Properties"

    Public Shared ConectionStringName As String = "FrontOfficeConnectionString"
    Private config As VisualTIME = CType(ConfigurationManager.GetSection("VisualTIMEConfigurationGroup/VisualTIMESection"), VisualTIME)

#End Region

#Region "Page Events"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack AndAlso Not IsCallback Then
            FillOneUsersInitComboBox()
            FillFrontOfficeUsersComboBox()
            FillSchemaBackOffice()
        End If
    End Sub

#End Region

#Region "Controls Events"

    Protected Sub WorkflowsCallbackPanel_Callback(sender As Object, e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles WorkflowsCallbackPanel.Callback

        If WorkflowsCheckBox.Checked Then
            Try
                'With New DataManagerFactory(True, "CleanWorkFlowInformation", "FrontOfficeConnectionString")
                '    .CommandExecute()
                'End With
                WorkflowsImageOK.Visible = True
            Catch ex As Exception
                WorkflowsImageFail.Visible = True
                WorkflowsLabel.Text = ex.InnerException.Message.ToString
            End Try

        End If
    End Sub

    Protected Sub TaskCallbackPanel_Callback(sender As Object, e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles TaskCallbackPanel.Callback
        If TaskCheckBox.Checked Then
            Try
                InMotionGIT.Agenda.Proxy.Manager.RemoveAllTasks()
                TaskImageOK.Visible = True
            Catch ex As Exception
                TaskImageFail.Visible = True
                TaskLabel.Text = ex.Message.ToString
            End Try
        End If
    End Sub

    Protected Sub RolesAndUsersCallbackPanel_Callback(sender As Object, e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles RolesAndUsersCallbackPanel.Callback

        If RolesAndUsersCheckBox.Checked Then
            RolesAndUsersCallbackPanel.JSProperties.Clear()

            Try
                CleanUsersInformation()
                CleanRolesInformation()
                Dim adminPassword As String = GenerateAdminUser()
                RolesAndUsersImageOK.Visible = True
                RolesAndUsersLabel.Text = String.Format(CultureInfo.InvariantCulture, GetLocalResourceObject("RolesAndUsersCallbackPanelMessage").ToString.Trim, adminPassword)
                RolesAndUsersCallbackPanel.JSProperties.Add("cp_OK", True)
                CountdownLabel.Visible = "True"

                ' Se agrega nuevamente el usuario conectado para que se pueda redireccionar sin problema
                If Not UserInfo.UserName.ToString.ToLower.Equals(config.Security.AdministratorUser.ToLower) Then
                    Dim config As VisualTIME = CType(ConfigurationManager.GetSection("VisualTIMEConfigurationGroup/VisualTIMESection"), VisualTIME)

                    UserManager("add", UserInfo.UserName, UserInfo.UserName, UserInfo.UserName, String.Empty, config.Security.DefaultRole,
                                InMotionGIT.Membership.Providers.Enumerations.enumUserType.Employee, String.Empty, String.Empty, Nothing, False, False, sendEmail:=True, IsEmployee:=True, IsAdministrator:=True, AllowScheduler:=True, SecurityLavel:=9)

                    LogHandler.WarningLog("Initialization", String.Format("El usuario {0} con el codigo: {1}, agrego el usuario {2}",
                                                                          UserInfo.UserName, UserCode, UserInfo.UserName))

                End If
            Catch ex As Exception
                RolesAndUsersImageFail.Visible = True
                RolesAndUsersLabel.Text = ex.Message.ToString
                RolesAndUsersCallbackPanel.JSProperties.Add("cp_OK", False)
            End Try
        End If

    End Sub

    Protected Sub RolesInitCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles RolesInitCallbackPanel.Callback

        If RolesInitCheckBox.Checked Then
            Try
                GenerateVisualTimeRoles()
                RolesInitImageOK.Visible = True

                RolesInitLabel.Visible = True
                RolesInitLabel.Text = GetLocalResourceObject("MessageRoleInitProcessCorrectly").ToString()
            Catch ex As Exception
                RolesInitImageFail.Visible = True
                RolesInitLabel.Text = ex.Message.ToString
            End Try
            RolesInitImageWarning.ClientVisible = False

        End If

    End Sub

    Protected Sub RolesConfigCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles RolesConfigCallbackPanel.Callback

        If RolesConfigCheckBox.Checked Then
            Try
                GenerateConfigurationRoles()
                RolesConfigImageOK.Visible = True
            Catch ex As Exception
                RolesConfigImageFail.Visible = True
                RolesConfigLabel.Text = ex.Message.ToString
            End Try
        End If
    End Sub

    Protected Sub UsersInitCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles UsersInitCallbackPanel.Callback

        If UsersInitCheckBox.Checked Then
            Try
                GenerateVisualTimeUsers()
                UsersInitImageOK.Visible = True
            Catch ex As Exception
                UsersInitImageFail.Visible = True
                UsersInitLabel.Text = ex.Message.ToString
            End Try
        End If

    End Sub

    Protected Sub OneUsersInitCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles OneUsersInitCallbackPanel.Callback
        If OneUsersInitCheckBox.Checked Then
            Try
                GenerateOneVisualTimeUser()
                OneUsersInitImageOK.Visible = True
            Catch ex As Exception
                OneUsersInitImageFail.Visible = True
                OneUsersInitLabel.Text = ex.Message.ToString
            End Try

        End If
    End Sub

    Protected Sub RedirectCallback_Callback(ByVal source As Object, ByVal e As DevExpress.Web.ASPxCallback.CallbackEventArgs) Handles RedirectCallback.Callback
        RedirectLogonPage()
    End Sub

    Protected Sub DocumentCacheCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles DocumentCacheCallbackPanel.Callback

        If DocumentCacheCheckBox.Checked Then
            Try
                CleanDocumentCacheInformation()
                DocumentCacheImageOK.Visible = True
            Catch ex As Exception
                DocumentCacheImageFail.Visible = True
                DocumentCacheLabel.Text = ex.Message.ToString
            End Try
        End If

    End Sub

    Protected Sub WidgetsInRolesInitCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles WidgetsInRolesInitCallbackPanel.Callback

        If WidgetsInRolesInitCheckBox.Checked Then
            Try
                GenerateWidgetsInRolesDefaultConfiguration()
                WidgetsInRolesInitImageOK.Visible = True
            Catch ex As Exception
                WidgetsInRolesInitImageFail.Visible = True
                WidgetsInRolesInitLabel.Text = ex.Message.ToString
            End Try
        End If

    End Sub

    Protected Sub NavigationDirectoryCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles NavigationDirectoryCallbackPanel.Callback

        If NavigationDirectoryCheckBox.Checked Then
            Try
                CleanNavigationDirectoryInformation()
                NavigationDirectoryImageOK.Visible = True
            Catch ex As Exception
                NavigationDirectoryImageFail.Visible = True
                NavigationDirectoryLabel.Text = ex.Message.ToString
            End Try
        End If

    End Sub

    Protected Sub AnonymousUsersCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles AnonymousUsersCallbackPanel.Callback

        If AnonymousUsersCheckBox.Checked Then
            Try
                CleanAnonymousUsersInformation()
                AnonymousUsersImageOK.Visible = True
            Catch ex As Exception
                AnonymousUsersImageFail.Visible = True
                AnonymousUsersLabel.Text = ex.Message.ToString
            End Try
        End If

    End Sub

    Protected Sub CopyUserConfigurationCallbackPanel_Callback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxClasses.CallbackEventArgsBase) Handles CopyUserConfigurationCallbackPanel.Callback

        If CopyUserConfigurationCheckBox.Checked Then
            Try
                CopyUserConfiguration()
                CopyUserConfigurationImageOK.Visible = True
            Catch ex As Exception
                CopyUserConfigurationImageFail.Visible = True
                CopyUserConfigurationLabel.Text = ex.Message.ToString
            End Try
        End If

    End Sub

#End Region

#Region "Generate Data Methods"

    Private Shared Sub GenerateConfigurationRoles()
        Dim config As VisualTIME = CType(ConfigurationManager.GetSection("VisualTIMEConfigurationGroup/VisualTIMESection"), VisualTIME)

        Dim AnonymousRole As String = config.Security.AnonymousRole
        If Not String.IsNullOrEmpty(AnonymousRole) Then
            If Not Roles.RoleExists(AnonymousRole) Then
                Roles.CreateRole(AnonymousRole)
                InMotionGIT.Membership.Providers.Helper.RoleSecurityLavelSet(AnonymousRole, 9, dropthings_Admin_Initialization.ConectionStringName)
            End If
        End If

        Dim ClientRole As String = config.Security.ClientRole
        If Not String.IsNullOrEmpty(ClientRole) Then
            If Not Roles.RoleExists(ClientRole) Then
                Roles.CreateRole(ClientRole)
                InMotionGIT.Membership.Providers.Helper.RoleSecurityLavelSet(ClientRole, 9, dropthings_Admin_Initialization.ConectionStringName)
            End If
        End If

        Dim ProducerRole As String = config.Security.ProducerRole
        If Not String.IsNullOrEmpty(ProducerRole) Then
            If Not Roles.RoleExists(ProducerRole) Then
                Roles.CreateRole(ProducerRole)
                InMotionGIT.Membership.Providers.Helper.RoleSecurityLavelSet(ProducerRole, 9, dropthings_Admin_Initialization.ConectionStringName)
            End If
        End If
    End Sub

    Private Sub GenerateVisualTimeRoles()
        Dim listWidgets As New List(Of InMotionGIT.FrontOffice.Contracts.Widget)
        Dim RolesDatar As DataTable
        Dim RolesList As New List(Of String)

        If chkCreateRoleBackOffice.Checked Then
            Dim ListBoxUsers As ASPxListBox = CType(chkBoxlistRoleBackOffice.FindControl("chkBoxlistRoleBackOfficeInter"), ASPxListBox)
            For Each item As ListEditItem In ListBoxUsers.SelectedItems
                RolesList.Add(item.Value.ToString.Trim)
            Next
        Else

            RolesDatar = SecuritySche()
            If RolesDatar.IsNotEmpty AndAlso RolesDatar.Rows.Count <> 0 Then
                For Each ItemRow As DataRow In RolesDatar.Rows
                    RolesList.Add(ItemRow.StringValue("SSCHE_CODE"))
                Next
            End If

        End If

        InMotionGIT.FrontOffice.Proxy.Helpers.WidgetsManager.SynchronizeSpecialWidgets(RolesList)

    End Sub

    Private Sub GenerateVisualTimeUsers()
        Dim UsersData As DataTable = GetDataUsersBackOffice(Integer.MinValue)
        Dim sUserName As String = String.Empty
        Dim sPassword As String = String.Empty
        Dim sSche_code As String = String.Empty
        Dim eMail As String = String.Empty
        Dim currentProfile As InMotionGIT.Membership.Providers.FrontOfficeMembershipUser = Nothing

        Dim invalidPassword As Boolean
        Dim secretQuestion As String = String.Empty
        Dim secretAnswer As String = String.Empty

        Using service As EncryptionService.EncryptionClient = New EncryptionService.EncryptionClient()
            Dim config As VisualTIME = VisualTIME.Configuration
            Dim count As Integer = 1

            For Each row As DataRow In UsersData.Rows
                If Not String.Equals(sUserName, row("SINITIALS").ToString.Trim, StringComparison.CurrentCultureIgnoreCase) Then
                    invalidPassword = False

                    sUserName = row("SINITIALS").ToString.Trim

                    sPassword = row("SACCESSWO").ToString.Trim
                    If sPassword.IsEmpty Then
                        sPassword = "1"
                    Else
                        sPassword = service.Decryption(sPassword)
                    End If

                    If Not AuthenticationHelper.IsCorrectPasswordBySettings(sPassword, Membership.MinRequiredPasswordLength, Membership.MinRequiredNonAlphanumericCharacters) Then
                        sPassword = AuthenticationHelper.CreateRandomPassword(Membership.MinRequiredPasswordLength, Membership.MinRequiredNonAlphanumericCharacters)
                        invalidPassword = True
                    End If

                    sSche_code = row("SSCHE_CODE").ToString.Trim

                    If Not config.Authentification.ForceEmailSuffix AndAlso Not IsDBNull(row("MAIL")) AndAlso
                       Not String.IsNullOrEmpty(row("MAIL").ToString.Trim()) Then

                        eMail = row("MAIL").ToString.Trim()
                    Else
                        eMail = String.Empty
                    End If

                    UserManager("delete", sUserName, String.Empty, String.Empty, String.Empty, String.Empty, InMotionGIT.Membership.Providers.Enumerations.enumUserType.User, String.Empty,
                                String.Empty, Nothing, False, True)

                    If String.Equals(config.Authentification.SecretQuestionKind, "Color", StringComparison.CurrentCultureIgnoreCase) Then
                        secretQuestion = GetGlobalResourceObject("Resource", "SecretQuestionColor").ToString()
                        secretAnswer = AuthenticationHelper.CreateRandomSecretAnswer()
                    Else
                        secretQuestion = GetGlobalResourceObject("Resource", "SecretEmailQuestion").ToString()
                        secretAnswer = eMail
                    End If

                    currentProfile = UserManager("add", sUserName, sUserName, sPassword, eMail, sSche_code,
                                                InMotionGIT.Membership.Providers.Enumerations.enumUserType.Employee, secretQuestion, secretAnswer, row, invalidPassword, False, False, IsEmployee:=True, IsAdministrator:=False, AllowScheduler:=True, SecurityLavel:=9)

                    LogHandler.WarningLog("Initialization", String.Format("Usuario '{0}' de '{1}', El usuario {2} con el codigo: {3}, elimino el usuario {4}",
                                                                         count, UsersData.Rows.Count, Profile.UserName, UserCode, sUserName))
                    'Send email
                    If SendCredentialsAllUsersCheckBox.Checked Then
                        InMotionGIT.FrontOffice.Support.User.SendEmailForUsers(currentProfile, secretQuestion, secretAnswer, sPassword, eMail)
                    End If
                End If
                count += 1
            Next

            service.Close()
        End Using
    End Sub

    Private Sub GenerateOneVisualTimeUser()
        Try

            Dim ListBoxUsers As ASPxListBox = CType(OneUsersInitDropDownEdit.FindControl("OneUsersInitListBox"), ASPxListBox)
            Dim sUserName As String = String.Empty
            Dim sPassword As String = String.Empty
            Dim sSche_code As String = String.Empty
            Dim eMail As String = String.Empty
            Dim invalidPassword As Boolean
            Dim UsersData As DataTable

            Dim currentProfile As InMotionGIT.Membership.Providers.FrontOfficeMembershipUser = Nothing

            Using service As EncryptionService.EncryptionClient = New EncryptionService.EncryptionClient()
                Dim config As VisualTIME = VisualTIME.Configuration

                For Each item As ListEditItem In ListBoxUsers.SelectedItems

                    UsersData = GetDataUsersBackOffice(item.Value)
                    If Not IsNothing(UsersData) Then
                        Dim secretQuestion As String = String.Empty
                        Dim secretAnswer As String = String.Empty

                        sUserName = UsersData.Rows(0).Item("SINITIALS").ToString.Trim

                        InMotionGIT.Common.Helpers.LogHandler.WarningLog("Initialization", String.Format("El usuario {0} con el código {1}, inicializo el usuario {2}",
                                                                                                                              Profile.UserName, UserCode, sUserName))
                        sPassword = UsersData.Rows(0).Item("SACCESSWO").ToString.Trim
                        If sPassword.IsEmpty Then
                            sPassword = "1"
                        Else
                            sPassword = service.Decryption(sPassword)
                        End If

                        If Not AuthenticationHelper.IsCorrectPasswordBySettings(sPassword, Membership.MinRequiredPasswordLength, Membership.MinRequiredNonAlphanumericCharacters) Then
                            sPassword = AuthenticationHelper.CreateRandomPassword(Membership.MinRequiredPasswordLength, Membership.MinRequiredNonAlphanumericCharacters)
                            invalidPassword = True
                        End If

                        sSche_code = UsersData.Rows(0).Item("SSCHE_CODE").ToString.Trim

                        If Not config.Authentification.ForceEmailSuffix AndAlso Not IsDBNull(UsersData.Rows(0).Item("MAIL")) AndAlso
                           Not String.IsNullOrEmpty(UsersData.Rows(0).Item("MAIL").ToString.Trim()) Then

                            eMail = UsersData.Rows(0).Item("MAIL").ToString.Trim()
                        Else
                            eMail = String.Empty
                        End If

                        UserManager("delete", sUserName, String.Empty, String.Empty, String.Empty, String.Empty, InMotionGIT.Membership.Providers.Enumerations.enumUserType.User, String.Empty,
                                   String.Empty, Nothing, False, True)

                        InMotionGIT.Common.Helpers.LogHandler.WarningLog("Initialization", String.Format("El usuario {0} con el codigo: {1}, elimino el usuario {2}",
                                                                                                                              Profile.UserName, UserCode, sUserName))

                        If String.Equals(config.Authentification.SecretQuestionKind, "Color", StringComparison.CurrentCultureIgnoreCase) Then
                            secretQuestion = GetGlobalResourceObject("Resource", "SecretQuestionColor").ToString()
                            secretAnswer = AuthenticationHelper.CreateRandomSecretAnswer()
                        Else
                            secretQuestion = GetGlobalResourceObject("Resource", "SecretEmailQuestion").ToString()
                            secretAnswer = eMail
                        End If

                        currentProfile = UserManager("add", sUserName, sUserName, sPassword, eMail, sSche_code,
                                                     InMotionGIT.Membership.Providers.Enumerations.enumUserType.Employee, secretQuestion, secretAnswer, UsersData.Rows(0),
                                                     invalidPassword, False, SendCredentialsSomeUsersCheckBox.Checked, IsEmployee:=True, IsAdministrator:=False, AllowScheduler:=True, SecurityLavel:=9, PasswordNeverExpires:=False)

                    End If
                Next

                service.Close()
            End Using
        Catch ex As Exception
            LogHandler.ErrorLog("Error de iniciar un usuario", ex.Message, ex)
        End Try
    End Sub

    Private Function GenerateAdminUser() As String
        Dim password As String = AuthenticationHelper.CreateAdministratorPassword(Membership.MinRequiredPasswordLength,
                                                                                  Membership.MinRequiredNonAlphanumericCharacters)
        UserManager("delete", config.Security.AdministratorUser, config.Security.AdministratorUser, String.Empty, String.Empty, String.Empty, InMotionGIT.Membership.Providers.Enumerations.enumUserType.User, String.Empty, String.Empty, Nothing, False, True)

        LogHandler.WarningLog("Initialization", String.Format(CultureInfo.InvariantCulture, "El usuario {0} con el codigo: {1}, elimino el usuario {2}",
                                                              Profile.UserName, UserCode, config.Security.AdministratorUser.ToLower))

        UserManager("add", config.Security.AdministratorUser, config.Security.AdministratorUser, password, String.Format("{0}@visualtime.com", config.Security.AdministratorUser), config.Security.DefaultRole, InMotionGIT.Membership.Providers.Enumerations.enumUserType.User,
                    GetGlobalResourceObject("Resource", "SecretQuestionColor").ToString(), String.Empty, Nothing, False, False, False, IsEmployee:=False, IsAdministrator:=True, AllowScheduler:=False, SecurityLavel:=9)

        LogHandler.WarningLog("Initialization", String.Format(CultureInfo.InvariantCulture, "El usuario {0} con el codigo: {1}, agrego el usuario {2}",
                                                              Profile.UserName, UserCode, config.Security.AdministratorUser.ToLower))
        Return password
    End Function

    Public Function UserCode() As String
        Dim Resul As String = ""
        If Not IsNothing(Session("nUsercode")) Then
            UserCode = Session("nUsercode").ToString
        End If
        Return Resul
    End Function

    Private Sub GenerateWidgetsInRolesDefaultConfiguration()
        With New InMotionGIT.Common.Proxy.DataManagerFactory(True, "INIWIDGINROLE", "FrontOfficeConnectionString")
            .ProcedureExecute()
        End With
    End Sub

#End Region

#Region "Fill Data Methods"

    Private Sub FillOneUsersInitComboBox()
        Dim ListBoxUsers As ASPxListBox = CType(OneUsersInitDropDownEdit.FindControl("OneUsersInitListBox"), ASPxListBox)

        If Not IsNothing(ListBoxUsers) Then
            With ListBoxUsers
                Dim dataSourceTable As DataTable = GetUsersBackOfficeLookup()
                Dim removeUser As Boolean = True
                Dim userName As String = String.Empty

                While removeUser
                    removeUser = False

                    For Each user As DataRow In dataSourceTable.Rows
                        If String.Equals(userName, user("SINITIALS").ToString.Trim, StringComparison.CurrentCultureIgnoreCase) Then
                            dataSourceTable.Rows.Remove(user)
                            userName = String.Empty

                            removeUser = True
                            Exit For
                        End If

                        userName = user("SINITIALS").ToString.Trim
                    Next
                End While

                .DataSource = dataSourceTable
                .DataBind()
            End With
        End If
    End Sub

    Private Sub FillFrontOfficeUsersComboBox()
        With CopyUserConfigurationComboBox
            .DataSource = RetrieveDataUsersFrontOffice()
            .DataBind()
        End With
    End Sub

    Private Sub FillSchemaBackOffice()
        Dim ListBoxUsers As ASPxListBox = CType(chkBoxlistRoleBackOffice.FindControl("chkBoxlistRoleBackOfficeInter"), ASPxListBox)
        With ListBoxUsers
            .DataSource = SecuritySche()
            .DataBind()
        End With
    End Sub

#End Region

#Region "Clear Data Methods"

    Private Sub CleanUsersInformation()
        With New DataManagerFactory("DELETE FROM WIDGETINSTANCETRANS", "WIDGETINSTANCETRANS", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
        With New DataManagerFactory("DELETE FROM WIDGETINSTANCE", "WIDGETINSTANCE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
        With New DataManagerFactory("DELETE FROM PAGETRANS", "PAGETRANS", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
        With New DataManagerFactory("DELETE FROM PAGE", "PAGE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
        With New DataManagerFactory("DELETE FROM USERSETTING", "WIDGETINSTANCE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
        With New DataManagerFactory("DELETE FROM USERMEMBERROLE", "USERMEMBERROLE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
        With New DataManagerFactory("DELETE FROM USERMEMBER", "USERMEMBER", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
    End Sub

    Private Sub CleanRolesInformation()
        With New DataManagerFactory("DELETE FROM WIDGETSINROLES", "WIDGETSINROLES", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With

        With New DataManagerFactory("DELETE FROM USERMEMBERROLE", "USERMEMBERROLE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With

        With New DataManagerFactory("DELETE FROM ROLE", "ROLE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute()
        End With
    End Sub

    Private Sub CleanDocumentCacheInformation()
        With New DataManagerFactory(" DELETE FROM DOCUMENTCACHE ", "DOCUMENTCACHE", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute(True)
        End With
    End Sub

    Private Sub CleanAnonymousUsersInformation()
        Dim rowsAffected As Integer = 0
        Dim listUser As New List(Of Integer)
        Dim listPage As New List(Of Integer)

        With New DataManagerFactory("SELECT USERID " &
                                      "FROM USERMEMBER " &
                                     "WHERE ISANONYMOUS = 1", "USERMEMBER", dropthings_Admin_Initialization.ConectionStringName)
            Dim ResulTable As DataTable = .QueryExecuteToTable(True)
            If ResulTable IsNot Nothing Then
                If ResulTable.Rows.Count <> 0 Then
                    For Each ItemRow As DataRow In ResulTable.Rows
                        listUser.Add(ItemRow.IntegerValue("USERID"))
                    Next
                End If
            End If
        End With

        If listUser.Count <> 0 Then

            For Each itemUser In listUser

                With New DataManagerFactory("SELECT ID " &
                                             "FROM PAGE " &
                                            "WHERE USERID = @:USERID", "PAGE", dropthings_Admin_Initialization.ConectionStringName)
                    .AddParameter("USERID", DbType.Decimal, 9, False, itemUser)

                    Dim ResulTable As DataTable = .QueryExecuteToTable(True)

                    If ResulTable IsNot Nothing Then
                        If ResulTable.Rows.Count <> 0 Then
                            listPage = New List(Of Integer)

                            For Each ItemRow As DataRow In ResulTable.Rows
                                listPage.Add(ItemRow.IntegerValue("ID"))
                            Next
                        Else
                            listPage = New List(Of Integer)
                        End If
                    Else
                        listPage = New List(Of Integer)
                    End If
                End With

                Dim QueryDeletePageTransWhere As String = String.Empty
                Dim QueryDeletePageTrans As String = String.Empty

                'Se elimina los PAGETRANS
                If listPage.Count <> 0 Then
                    QueryDeletePageTransWhere = String.Join(",", listPage.ToArray)

                    QueryDeletePageTrans = String.Format("DELETE  " &
                                                                       "  FROM PAGETRANS " &
                                                                       " WHERE ID IN ({0})", QueryDeletePageTransWhere)

                    With New DataManagerFactory(QueryDeletePageTrans,
                                                "PAGETRANS",
                                                dropthings_Admin_Initialization.ConectionStringName)
                        .CommandExecute()
                    End With
                Else
                    QueryDeletePageTransWhere = String.Empty
                    QueryDeletePageTrans = String.Empty
                End If

                'Se elimna los WIDGETINSTANCETRANS y WIDGETINSTANCE
                For Each itemPage In listPage
                    With New DataManagerFactory("DELETE " &
                                                  "FROM WIDGETINSTANCETRANS " &
                                                 "WHERE PAGEID = @:PAGEID", "WIDGETINSTANCETRANS", dropthings_Admin_Initialization.ConectionStringName)
                        .AddParameter("PAGEID", DbType.Decimal, 9, False, itemPage)
                        .CommandExecute()
                    End With

                    With New DataManagerFactory("DELETE " &
                                                  "FROM WIDGETINSTANCE " &
                                                 "WHERE PAGEID = @:PAGEID", "WIDGETINSTANCE", dropthings_Admin_Initialization.ConectionStringName)
                        .AddParameter("PAGEID", DbType.Decimal, 9, False, itemPage)
                        .CommandExecute()
                    End With

                Next

                'Se elimna los PAGE
                If listPage.Count <> 0 Then
                    QueryDeletePageTransWhere = String.Join(",", listPage.ToArray)

                    QueryDeletePageTrans = String.Format("DELETE  " &
                                                         "  FROM PAGE " &
                                                         " WHERE ID IN ({0})", QueryDeletePageTransWhere)

                    With New DataManagerFactory(QueryDeletePageTrans,
                                                "PAGE",
                                                dropthings_Admin_Initialization.ConectionStringName)
                        .CommandExecute()
                    End With
                Else
                    QueryDeletePageTransWhere = String.Empty
                    QueryDeletePageTrans = String.Empty
                End If

                With New DataManagerFactory("DELETE " &
                                            "  FROM USERMEMBERROLE " &
                                             "WHERE USERID = @:USERID", "USERMEMBERROLE", dropthings_Admin_Initialization.ConectionStringName)
                    .AddParameter("USERID", DbType.Decimal, 9, False, itemUser)
                    .CommandExecute()
                End With

                With New DataManagerFactory("DELETE " &
                                             "FROM USERSETTING " &
                                            "WHERE USERID = @:USERID", "USERSETTING", dropthings_Admin_Initialization.ConectionStringName)
                    .AddParameter("USERID", DbType.Decimal, 9, False, itemUser)
                    .CommandExecute()
                End With

                With New DataManagerFactory("DELETE " &
                                              "FROM USERMEMBER " &
                                             "WHERE USERID = @:USERID ", "USERMEMBER", dropthings_Admin_Initialization.ConectionStringName)

                    .AddParameter("USERID", DbType.String, 255, False, itemUser)
                    rowsAffected = .CommandExecute
                End With

            Next

        End If

    End Sub

    Private Sub CleanNavigationDirectoryInformation()
        With New DataManagerFactory(" DELETE FROM NAVIGATIONDIRECTORYDESC ", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute(True)
        End With
        With New DataManagerFactory(" DELETE FROM NAVIGATIONDIRECTORY ", dropthings_Admin_Initialization.ConectionStringName)
            .CommandExecute(True)
        End With
    End Sub

#End Region

#Region "Custom Methods"

    Private Sub RedirectLogonPage()

        ' Se elimina el usuario actual y se envia a la página de login
        If Not UserInfo.UserName.ToLower.Equals(config.Security.AdministratorUser.ToLower) Then
            UserManager("delete", UserInfo.UserName, UserInfo.UserName, String.Empty, String.Empty, String.Empty, InMotionGIT.Membership.Providers.Enumerations.enumUserType.User, String.Empty,
                        String.Empty, Nothing, False, True)
            InMotionGIT.Common.Helpers.LogHandler.WarningLog("Initialization", String.Format("El usuario {0} con el codigo: {1}, elimina el usuario {2}",
                                                                                              UserInfo.UserName, UserCode, UserInfo.UserName))
        End If

        FormsAuthentication.SignOut()

        If IsCallback Then
            DevExpress.Web.ASPxClasses.ASPxWebControl.RedirectOnCallback("~/dropthings/Default.aspx")
        Else
            Response.Redirect("~/dropthings/Default.aspx")
        End If

    End Sub

    Shared _configurations As InMotionGIT.Core.Configuration.FASIConfiguration = InMotionGIT.Core.Configuration.FASIConfiguration.Configuration()

    Public Shared Function SecuritySche() As DataTable
        Dim result As DataTable = Nothing

        Dim settingService As SettingsService.SettingsClient = New SettingsService.SettingsClient()
        Dim companies As InMotionGIT.FrontOffice.Proxy.SettingsService.MultiCompany() = settingService.MultiCompanyList
        For Each itemCompnay In companies
            With New DataManagerFactory("SELECT SSCHE_CODE FROM SECUR_SCHE WHERE SSTATREGT = '1'", "SSCHE_CODE", "BackOfficeConnectionString")
                .CompanyId = itemCompnay.Identification
                .Cache = InMotionGIT.Common.Enumerations.EnumCache.CacheWithFullParameters
                If result Is Nothing Then
                    result = .QueryExecuteToTable(True)
                Else
                    Dim resultSecuritySchem = .QueryExecuteToTable(True)
                    For Each row As DataRow In resultSecuritySchem.Rows
                        Dim rows = result.Select(String.Format("SSCHE_CODE='{0}'", row.StringValue("SSCHE_CODE")))
                        If rows.Length = 0 Then
                            result.ImportRow(row)
                        End If
                    Next
                End If
            End With
        Next

        Dim dv As DataView = result.DefaultView
        dv.Sort = "SSCHE_CODE ASC"
        result = dv.ToTable()

        Return result
    End Function

    Private Shared Function RetrieveDataUsersFrontOffice() As List(Of Object)
        Dim result As New List(Of Object)
        Dim VTSchemesList As DataTable = Nothing
        Dim SchemesList As New List(Of String)
        Dim filter As String = String.Empty

        VTSchemesList = SecuritySche()

        For Each row As DataRow In VTSchemesList.Rows
            SchemesList.Add(row.StringValue("SSCHE_CODE"))
        Next

        SchemesList = (From item In SchemesList Select String.Format("'{0}'", item)).ToList
        SchemesList.Add(String.Format("'{0}'", _configurations.Security.AdministratorRole))

        filter = String.Join(",", SchemesList)
        Dim query As String = String.Format("	SELECT " +
                                                "		USERMEMBER.USERID, " +
                                                "		USERMEMBER.USERNAME, " +
                                                "		( " +
                                                "			SELECT " +
                                                "				COUNT (*) " +
                                                "			FROM " +
                                                "				ROLE " +
                                                "			WHERE " +
                                                "				ROLEINTERNAL.ROLEID = ROLE.ROLEID " +
                                                "			AND LOWER(ROLE.ROLENAME) = LOWER('{1}') " +
                                                "		) ADMINBYROLE, " +
                                                "		USERMEMBER.ISADMINISTRATOR ADMINBYPROPERTY " +
                                                "	FROM " +
                                                "		USERMEMBER " +
                                                "	INNER JOIN USERMEMBERROLE ON USERMEMBER.USERID = USERMEMBERROLE.USERID " +
                                                "	INNER JOIN ROLE ROLEINTERNAL ON USERMEMBERROLE.ROLEID = ROLEINTERNAL.ROLEID " +
                                                "	WHERE " +
                                                "		USERMEMBER.ISANONYMOUS = 0 " +
                                                "	AND ROLEINTERNAL.ROLENAME IN ({0}) " +
                                                "	ORDER BY " +
                                                "		USERNAME ASC  ", filter, _configurations.Security.AdministratorRole)
        With New DataManagerFactory(query,
                                    "USERMEMBER", ConectionStringName)
            Dim resulQuery = .QueryExecuteToTable(True)
            If resulQuery.IsNotEmpty AndAlso resulQuery.Rows.Count <> 0 Then
                For Each ItemRow As DataRow In resulQuery.Rows
                    Dim ISADMINISTRATOR = False
                    If ItemRow.IntegerValue("ADMINBYPROPERTY") <> 0 Or ItemRow.IntegerValue("ADMINBYROLE") <> 0 Then
                        ISADMINISTRATOR = True
                    End If
                    result.Add(New With {Key .UserName = ItemRow.StringValue("USERNAME"),
                                         Key .ProviderUserKey = ItemRow.IntegerValue("USERID"),
                                         Key .IsAdministrator = ISADMINISTRATOR
                               })
                Next
            End If
        End With

        Return result
        'Dim _MembershipUsersCollection As MembershipUserCollection = Membership.GetAllUsers()
        'Dim _MembershipUsersCollectionNew As New MembershipUserCollection
        ' Dim schemas = GetSchemes()

        'For Each ItemUser As MembershipUser In _MembershipUsersCollection
        '    Dim roles As String() = System.Web.Security.Roles.GetRolesForUser(ItemUser.UserName)
        '    If roles.IsNotEmpty AndAlso roles.Count <> 0 Then
        '        For Each ItemRole As String In roles
        '            If schemas.Contains(ItemRole) Then
        '                _MembershipUsersCollectionNew.Add(ItemUser)
        '            End If
        '        Next
        '    End If
        'Next

        'Return _MembershipUsersCollectionNew
    End Function

    Private Sub CopyUserConfiguration()
        Dim _MembershipUsersCollection As List(Of Object) = RetrieveDataUsersFrontOffice()

        Dim _MembershipUserOrigin As MembershipUser = Membership.GetUser(CopyUserConfigurationComboBox.SelectedItem.Value.ToString)
        Dim UserIdOrigin As Integer = _MembershipUserOrigin.ProviderUserKey
        Dim UserIdDestiny As Integer
        Dim IsAdminUser As Boolean = False
        Dim IsSameUser As Boolean = False
        Dim CopyConfigurationOption As String = CopyUserConfigurationRadioButtonList.SelectedItem.Value.ToString
        Dim RoleNameOrigin As String = String.Empty
        Dim RoleNameDestiny As String = String.Empty
        Dim VTSchemesList As String = GetSchemes()
        Dim listPageOrigin As List(Of InMotionGIT.FrontOffice.Contracts.Page)
        Dim listWidgetInstance As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstance)
        Dim listWidgetIntanceTrans As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstanceTrans)

        '+ Se obtiene el rol Origen el cual es equivalente a el Esquema de Seguridad de VTIME
        For Each _Role As String In Roles.GetRolesForUser(_MembershipUserOrigin.UserName)
            If VTSchemesList.ToLower.Contains(_Role.ToLower) Then
                RoleNameOrigin = _Role
            End If
        Next

        For Each _MembershipUserDestiny As Object In _MembershipUsersCollection
            Dim userTemporal = _MembershipUserDestiny
            UserIdDestiny = userTemporal.ProviderUserKey
            IsSameUser = String.Equals(UserIdDestiny.ToString, UserIdOrigin.ToString)
            IsAdminUser = userTemporal.IsAdministrator

            listPageOrigin = PageListOrigin(UserIdOrigin)
            listWidgetInstance = WidgetInstanceFromPage(listPageOrigin)
            listWidgetIntanceTrans = WidgetInstanceTransFromWidgetInstance(listWidgetInstance)

            If Not IsAdminUser And Not IsSameUser Then

                '+ Se obtiene el rol Destino el cual es equivalente a el Esquema de Seguridad de VTIME
                For Each _Role As String In Roles.GetRolesForUser(_MembershipUserDestiny.UserName)
                    If VTSchemesList.ToLower.Contains(_Role.ToLower) Then
                        RoleNameDestiny = _Role
                    End If
                Next
                int_CopyUserConfiguration(listPageOrigin, listWidgetInstance, listWidgetIntanceTrans, UserIdOrigin, UserIdDestiny, CopyConfigurationOption, RoleNameOrigin, RoleNameDestiny)

            End If
        Next
    End Sub

    Shared Function GetSchemes() As String
        Dim VTSchemesList As DataTable = SecuritySche()

        Dim VTSchemesString As String = String.Empty

        For Each row As DataRow In VTSchemesList.Rows
            If VTSchemesString.Length > 0 Then VTSchemesString += ","
            VTSchemesString += row.Item("SSCHE_CODE").ToString().Trim
        Next

        Return VTSchemesString
    End Function

#End Region

#Region "Data access methods, for internal use"

    Public Function WidgetInstanceTransFromWidgetInstance(widgets As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstance)) As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstanceTrans)
        Dim result As New List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstanceTrans)
        Dim vectorIds As Integer() = (From itemPage In widgets Select itemPage.Id).ToArray()
        With New DataManagerFactory(String.Format(" SELECT ID, " +
                                                    "        PAGEID, " +
                                                    "        WIDGETID, " +
                                                    "        LANGUAGEID, " +
                                                    "        TITLE, " +
                                                    "        CREATORUSERCODE, " +
                                                    "        CREATIONDATE, " +
                                                    "        UPDATEDATE " +
                                                    "  FROM WIDGETINSTANCETRANS " +
                                                    " WHERE WIDGETINSTANCETRANS.ID IN ({0}) ", String.Join(",", vectorIds)),
                                            "PAGE", ConectionStringName)
            .Cache = InMotionGIT.Common.Enumerations.EnumCache.CacheWithFullParameters
            Dim ResulTransTable As DataTable = .QueryExecuteToTable(True)
            If ResulTransTable IsNot Nothing Then
                If ResulTransTable.Rows.Count <> 0 Then
                    For Each ItemRow As DataRow In ResulTransTable.Rows
                        Dim temporalPageId As Integer = ItemRow.IntegerValue("ID")
                        Dim temporalWidgetInstanceTrans As New InMotionGIT.FrontOffice.Contracts.WidgetInstanceTrans
                        With temporalWidgetInstanceTrans
                            .Id = ItemRow.IntegerValue("ID")
                            .PageId = ItemRow.IntegerValue("PAGEID")
                            .WidgetId = ItemRow.IntegerValue("WIDGETID")
                            .LanguageID = ItemRow.IntegerValue("LANGUAGEID")
                            .Title = ItemRow.StringValue("TITLE")
                        End With
                        result.Add(temporalWidgetInstanceTrans)
                    Next
                End If
            End If
        End With
        Return result
    End Function

    Public Function WidgetInstanceFromPage(pages As List(Of InMotionGIT.FrontOffice.Contracts.Page)) As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstance)
        Dim result As New List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstance)
        Dim vectorIds As Integer() = (From itemPage In pages Select itemPage.ID).ToArray()
        With New DataManagerFactory(String.Format(" SELECT WIDGETINSTANCE.ID, " +
                                                  "        WIDGETINSTANCE.TITLE, " +
                                                  "        WIDGETINSTANCE.PAGEID, " +
                                                  "        WIDGETINSTANCE.WIDGETID, " +
                                                  "        WIDGETINSTANCE.COLUMNNO, " +
                                                  "        WIDGETINSTANCE.ORDERNO, " +
                                                  "        WIDGETINSTANCE.EXPANDED, " +
                                                  "        WIDGETINSTANCE.STATE, " +
                                                  "        WIDGETINSTANCE.VERSIONNO, " +
                                                  "        WIDGETINSTANCE.CREATEDDATE, " +
                                                  "        WIDGETINSTANCE.LASTUPDATE    " +
                                                  "   FROM WIDGETINSTANCE " +
                                                  "  WHERE PAGEID IN ({0}) ", String.Join(",", vectorIds)),
                                            "PAGE", ConectionStringName)
            .Cache = InMotionGIT.Common.Enumerations.EnumCache.CacheWithFullParameters
            Dim ResulTransTable As DataTable = .QueryExecuteToTable(True)
            If ResulTransTable IsNot Nothing Then
                If ResulTransTable.Rows.Count <> 0 Then
                    For Each ItemRow As DataRow In ResulTransTable.Rows
                        Dim temporalPageId As Integer = ItemRow.IntegerValue("ID")
                        Dim temporalWidgetInstance As New InMotionGIT.FrontOffice.Contracts.WidgetInstance
                        With temporalWidgetInstance
                            .Id = ItemRow.IntegerValue("ID")
                            .Title = ItemRow.IntegerValue("TITLE")
                            .PageId = ItemRow.IntegerValue("PAGEID")
                            .WidgetId = ItemRow.IntegerValue("WIDGETID")
                            .ColumnNo = ItemRow.IntegerValue("COLUMNNO")
                            .OrderNo = ItemRow.IntegerValue("ORDERNO")
                            .Expanded = IIf(ItemRow.StringValue("EXPANDED").Equals("0"), False, True)
                            .State = ItemRow.StringValue("STATE")
                            .VersionNo = ItemRow.IntegerValue("VERSIONNO")
                            '"        WIDGETINSTANCE.CREATEDDATE, " +
                            '"        WIDGETINSTANCE.LASTUPDATE    " +
                        End With
                        result.Add(temporalWidgetInstance)
                    Next
                End If
            End If
        End With
        Return result
    End Function

    Public Function PageListOrigin(UserIdOrigin As Integer) As List(Of InMotionGIT.FrontOffice.Contracts.Page)
        Dim listPagesOrigin As New List(Of InMotionGIT.FrontOffice.Contracts.Page)
        Dim keyListPage As String = String.Format("ConfigurationsPage{0}", UserIdOrigin)
        If InMotionGIT.Common.Helpers.Caching.NotExist(keyListPage) Then
            With New DataManagerFactory("Select ID, Title, USERID, VERSIONNO, LAYOUTTYPE" &
                                         " FROM PAGE" &
                                        " WHERE USERID = @: USERID", "PAGE", ConectionStringName)
                .AddParameter("USERID", DbType.Decimal, 9, False, UserIdOrigin)
                .Cache = InMotionGIT.Common.Enumerations.EnumCache.CacheWithFullParameters
                Dim ResulTable As DataTable = .QueryExecuteToTable(True)
                If ResulTable IsNot Nothing Then
                    If ResulTable.Rows.Count <> 0 Then
                        For Each ItemRow As DataRow In ResulTable.Rows
                            listPagesOrigin.Add(InMotionGIT.FrontOffice.Proxy.Helpers.Mapper.PageEntityToContract(ItemRow))
                        Next
                    End If
                End If
            End With

            If listPagesOrigin.IsNotEmpty AndAlso listPagesOrigin.Count <> 0 Then
                'Se optione las traducciones de las paginas
                Dim vectorIds As Integer() = (From itemPage In listPagesOrigin Select itemPage.ID).ToArray()
                With New DataManagerFactory(String.Format("SELECT * " &
                                                          "  FROM PAGETRANS " &
                                                          " WHERE PAGETRANS.ID IN ({0})", String.Join(",", vectorIds)),
                                            "PAGE", ConectionStringName)
                    .Cache = InMotionGIT.Common.Enumerations.EnumCache.CacheWithFullParameters
                    Dim ResulTransTable As DataTable = .QueryExecuteToTable(True)
                    If ResulTransTable IsNot Nothing Then
                        If ResulTransTable.Rows.Count <> 0 Then
                            For Each ItemRow As DataRow In ResulTransTable.Rows
                                Dim temporalPageId As Integer = ItemRow.IntegerValue("ID")
                                Dim temporalPage As InMotionGIT.FrontOffice.Contracts.Page = (From itemPage In listPagesOrigin
                                                                                              Where itemPage.ID = temporalPageId
                                                                                              Select itemPage).FirstOrDefault
                                If temporalPage.IsNotEmpty Then
                                    If temporalPage.TranslationTitle.IsEmpty Then
                                        temporalPage.TranslationTitle = New List(Of InMotionGIT.Common.DataType.LookUpValue)
                                    End If
                                    With temporalPage.TranslationTitle
                                        .Add(New InMotionGIT.Common.DataType.LookUpValue With {.Code = ItemRow.StringValue("LANGUAGEID"), .Description = ItemRow.StringValue("TITLE")})
                                    End With
                                End If
                            Next
                        End If
                    End If
                End With
            End If
            InMotionGIT.Common.Helpers.Caching.SetItem(keyListPage, listPagesOrigin)
        Else
            listPagesOrigin = InMotionGIT.Common.Helpers.Caching.GetItem(keyListPage)
        End If
        Return listPagesOrigin
    End Function

    Private Sub int_CopyUserConfiguration(listPageOrigin As List(Of Page), listWidgetInstance As List(Of WidgetInstance), listWidgetIntanceTrans As List(Of WidgetInstanceTrans), userIdOrigin As Integer, userIdDestiny As Integer, copyConfigurationOption As String, roleNameOrigin As String, roleNameDestiny As String)

        With New DataManagerFactory(String.Format(" DELETE FROM WIDGETINSTANCETRANS " +
                                                    "       WHERE WIDGETINSTANCETRANS.ID IN (SELECT WIDGETINSTANCE.ID " +
                                                    "                                          FROM WIDGETINSTANCE " +
                                                    "                                         WHERE WIDGETINSTANCE.PAGEID IN (SELECT PAGE.ID " +
                                                    "                                                                           FROM PAGE " +
                                                    "                                                                          WHERE PAGE.USERID = " +
                                                    "                                                                                   {0}))", userIdDestiny),
                                                    "WIDGETINSTANCETRANS", ConectionStringName)
            .CommandExecute()
        End With

        With New DataManagerFactory(String.Format(" DELETE FROM WIDGETINSTANCE " +
                                                    "       WHERE WIDGETINSTANCE.PAGEID IN (SELECT PAGE.ID " +
                                                    "                                         FROM PAGE " +
                                                    "                                        WHERE PAGE.USERID = {0}) ", userIdDestiny),
                                                    "WIDGETINSTANCE", ConectionStringName)
            .CommandExecute()
        End With

        With New DataManagerFactory(String.Format(" DELETE FROM PAGETRANS " +
                                                  "       WHERE PAGETRANS.ID IN (SELECT PAGE.ID " +
                                                  "                                FROM PAGE " +
                                                  "                               WHERE PAGE.USERID = {0}) ", userIdDestiny),
                                                  "PAGE", ConectionStringName)
            .CommandExecute()
        End With

        With New DataManagerFactory(String.Format(" DELETE FROM PAGE " +
                                                    "      WHERE PAGE.USERID = {0} ", userIdDestiny),
                                                    "PAGE", ConectionStringName)
            .CommandExecute()
        End With

        With New DataManagerFactory(String.Format(" DELETE FROM USERSETTING " +
                                                  "       WHERE USERSETTING.USERID = {0} ", userIdDestiny),
                                                    "PAGE", ConectionStringName)
            .CommandExecute()
        End With

        Dim isFirst As Boolean = True
        Dim PageIdFirst As Integer
        For Each itemPage In listPageOrigin

            Dim PageId As Integer

            With New DataManagerFactory(String.Format("SELECT NVL(MAX (ID), 0) + 1 FROM PAGE", userIdDestiny),
                                                    "PAGE", ConectionStringName)
                PageId = .QueryExecuteScalarToInteger()
            End With

            If isFirst Then
                PageIdFirst = PageId
                isFirst = False
            End If

            With itemPage
                Dim query As String = String.Format(" INSERT INTO PAGE (ID, " +
                                                    "                   USERID, " +
                                                    "                   CREATEDDATE, " +
                                                    "                   LASTUPDATE, " +
                                                    "                   VERSIONNO, " +
                                                    "                   LAYOUTTYPE) " +
                                                    "      VALUES ({0}, " +
                                                    "              {1}, " +
                                                    "              SYSDATE, " +
                                                    "              SYSDATE, " +
                                                    "              {1}, " +
                                                    "              {3}) ", PageId, userIdDestiny, .VersionNo, .LayoutType)
                With New DataManagerFactory(query,
                                                    "PAGE", ConectionStringName)
                    .CommandExecute()
                End With
            End With

            If itemPage.TranslationTitle.IsNotEmpty AndAlso itemPage.TranslationTitle.Count <> 0 Then
                For Each ItemPageTrans In itemPage.TranslationTitle
                    With New DataManagerFactory(" INSERT INTO PAGETRANS ( " &
                                          " 	ID, " &
                                          " 	LANGUAGEID, " &
                                          " 	TITLE, " &
                                          " 	CREATEDDATE, " &
                                          " 	LASTUPDATE " &
                                          " ) " &
                                          " VALUES 	" &
                                          " 	(@:ID, " &
                                          "    @:LANGUAGEID, " &
                                          "    @:TITLE, " &
                                          "    SYSDATE, " &
                                          "    SYSDATE) ",
                                          "PAGETRANS", ConectionStringName)
                        .AddParameter("ID", DbType.Decimal, 9, False, PageId)
                        .AddParameter("LANGUAGEID", DbType.Decimal, 3, False, ItemPageTrans.Code)
                        .AddParameter("TITLE", DbType.StringFixedLength, 255, False, ItemPageTrans.Description)
                        .CommandExecute()
                    End With
                Next
            End If

            Dim listWidgetInstanceFound As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstance) = (From itemWidget In listWidgetInstance Where itemWidget.PageId = itemPage.ID).ToList
            If listWidgetInstanceFound.IsNotEmpty AndAlso listWidgetInstanceFound.Count <> 0 Then
                For Each ItemWidgetInstanceFound In listWidgetInstanceFound
                    Dim widgetInstanceId As Integer
                    With New DataManagerFactory(String.Format("SELECT NVL (MAX (ID), 0) + 1 FROM WIDGETINSTANCE", userIdDestiny),
                                                   "WIDGETINSTANCE", ConectionStringName)
                        widgetInstanceId = .QueryExecuteScalarToInteger()
                    End With
                    With New DataManagerFactory("INSERT INTO WIDGETINSTANCE ( " &
                                            "   ID, TITLE, PAGEID, " &
                                            "   WIDGETID, COLUMNNO, ORDERNO, " &
                                            "   EXPANDED, STATE, VERSIONNO,  " &
                                            "   CREATEDDATE, LASTUPDATE) " &
                                            "VALUES " &
                                            " (@:ID , " &
                                            "  @:TITLE , " &
                                            "  @:PAGEID , " &
                                            "  @:WIDGETID , " &
                                            "  @:COLUMNNO , " &
                                            "  @:ORDERNO , " &
                                            "  @:EXPANDED , " &
                                            "  @:STATE , " &
                                            "  @:VERSIONNO , " &
                                            "  SYSDATE , " &
                                            "  SYSDATE  )",
                                            "WIDGET", ConectionStringName)
                        .AddParameter("ID", DbType.Decimal, 9, False, widgetInstanceId)
                        .AddParameter("TITLE", DbType.AnsiString, 1, String.IsNullOrEmpty(ItemWidgetInstanceFound.Title), ItemWidgetInstanceFound.Title)
                        .AddParameter("PAGEID", DbType.Decimal, 9, False, PageId)
                        .AddParameter("WIDGETID", DbType.Decimal, 9, False, ItemWidgetInstanceFound.WidgetId)
                        .AddParameter("COLUMNNO", DbType.Decimal, 9, False, ItemWidgetInstanceFound.ColumnNo)
                        .AddParameter("ORDERNO", DbType.Decimal, 9, False, ItemWidgetInstanceFound.OrderNo)
                        .AddParameter("EXPANDED", DbType.Decimal, 1, False, IIf(ItemWidgetInstanceFound.Expanded, 1, 0))
                        .AddParameter("STATE", DbType.AnsiString, 255, String.IsNullOrEmpty(ItemWidgetInstanceFound.State), ItemWidgetInstanceFound.State)
                        .AddParameter("VERSIONNO", DbType.Decimal, 9, False, ItemWidgetInstanceFound.VersionNo)
                        .CommandExecute()

                        Dim listWidgetInstanceTransFound As List(Of InMotionGIT.FrontOffice.Contracts.WidgetInstanceTrans) = (From itemWidgetInstanceTrans In listWidgetIntanceTrans
                                                                                                                              Where itemWidgetInstanceTrans.PageId = itemPage.ID And itemWidgetInstanceTrans.Id = ItemWidgetInstanceFound.Id).ToList
                        If listWidgetInstanceTransFound.IsNotEmpty AndAlso listWidgetInstanceTransFound.Count <> 0 Then

                            For Each ItemWidgetInstanceTransFound In listWidgetInstanceTransFound
                                With New DataManagerFactory("INSERT INTO FRONTOFFICE.WIDGETINSTANCETRANS ( " &
                                             "   ID, PAGEID, WIDGETID, " &
                                             "   LANGUAGEID, TITLE, CREATORUSERCODE, " &
                                             "   CREATIONDATE, UPDATEUSERCODE, UPDATEDATE) " &
                                             "VALUES (  @:ID , " &
                                             "   @:PAGEID , " &
                                             "   @:WIDGETID , " &
                                             "   @:LANGUAGEID , " &
                                             "   @:TITLE , " &
                                             "   @:CREATORUSERCODE , " &
                                             "   SYSDATE , " &
                                             "   @:UPDATEUSERCODE , " &
                                             "   SYSDATE  )",
                                             "WIDGETINSTANCETRANS", ConectionStringName)
                                    .AddParameter("ID", DbType.Decimal, 9, False, widgetInstanceId)
                                    .AddParameter("PAGEID", DbType.Decimal, 9, False, PageId)
                                    .AddParameter("WIDGETID", DbType.Decimal, 9, False, widgetInstanceId)
                                    .AddParameter("LANGUAGEID", DbType.Decimal, 9, False, ItemWidgetInstanceTransFound.LanguageID)
                                    .AddParameter("TITLE", DbType.AnsiString, 255, String.IsNullOrEmpty(ItemWidgetInstanceTransFound.Title), ItemWidgetInstanceTransFound.Title)
                                    .AddParameter("CREATORUSERCODE", DbType.AnsiString, 255, False, "666")
                                    .AddParameter("UPDATEUSERCODE", DbType.AnsiString, 255, False, "666")
                                    .CommandExecute()
                                End With
                            Next
                        End If
                    End With

                Next
            End If

            If isFirst = False Then
                Dim exitSetting As Integer
                With New DataManagerFactory(" SELECT " +
                                                         " 	COUNT (*) " +
                                                         " FROM " +
                                                         " 	USERSETTING " +
                                                         " WHERE " +
                                                         " 	USERSETTING.USERID = @:USERID " +
                                                         " AND USERSETTING.CURRENTPAGEID = @:CURRENTPAGEID ", "USERSETTING", ConectionStringName)
                    .AddParameter("USERID", DbType.Decimal, 9, False, userIdDestiny)
                    .AddParameter("CURRENTPAGEID", DbType.Decimal, 9, False, PageIdFirst)
                    exitSetting = .QueryExecuteScalarToInteger()
                End With
                If exitSetting = 0 Then
                    With New DataManagerFactory("INSERT INTO USERSETTING (USERID, CURRENTPAGEID) " &
                                    " VALUES (@:USERID, @:CURRENTPAGEID)", "USERSETTING", ConectionStringName)
                        .AddParameter("USERID", DbType.Decimal, 9, False, userIdDestiny)
                        .AddParameter("CURRENTPAGEID", DbType.Decimal, 9, False, PageIdFirst)
                        .CommandExecute()
                    End With
                End If

            End If

        Next

    End Sub

#End Region

    ''' <summary>
    ''' Creates the users in the security schema to grant access to the resources. // Crea los usuarios en el esquema de seguridad para garantizar accesos a los recursos.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub btnCreateUsersInSecurity_Click(sender As Object, e As EventArgs) Handles btnCreateUsersInSecurity.Click
        Try
            ResponseHelper.Initialization()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    'Private Async Sub PostUsers()

    'End Sub
End Class